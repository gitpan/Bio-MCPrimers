
use ExtUtils::MakeMaker;

WriteMakefile('NAME'		 => 'Bio::MCPrimers',
	          'VERSION_FROM' => 'MCPrimers.pm',
);
